alert('pre'); for (var key in window.navigator) {window.navigator[key]}; alert('post');
