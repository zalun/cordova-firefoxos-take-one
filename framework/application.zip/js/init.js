require.config({
    baseUrl: 'js/lib',
});

requirejs(['../index']);

